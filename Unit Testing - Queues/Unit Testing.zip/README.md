# Comp 3450 Project 3

Author: Caleb Manor

## Instructions

No special instructrions. Simply run all tests. 

## Strengths

Unit tests accomplish all base requirements. 

## Weaknesses

No known bugs.